"use client"

import { useState, useEffect } from "react"
import { RefreshCw } from "lucide-react"

export function SyncIndicator() {
  const [syncing, setSyncing] = useState(false)
  const [lastSynced, setLastSynced] = useState<Date | null>(null)

  useEffect(() => {
    // Simulate periodic sync
    const syncInterval = setInterval(() => {
      setSyncing(true)

      // Simulate sync delay
      setTimeout(() => {
        setSyncing(false)
        setLastSynced(new Date())
      }, 800)
    }, 30000) // Sync every 30 seconds

    // Initial sync
    setSyncing(true)
    setTimeout(() => {
      setSyncing(false)
      setLastSynced(new Date())
    }, 800)

    return () => clearInterval(syncInterval)
  }, [])

  return (
    <div className="flex items-center text-xs text-muted-foreground">
      {syncing ? (
        <>
          <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
          <span>Syncing...</span>
        </>
      ) : (
        <>
          <RefreshCw className="h-3 w-3 mr-1" />
          <span>{lastSynced ? `Last synced: ${lastSynced.toLocaleTimeString()}` : "Synced"}</span>
        </>
      )}
    </div>
  )
}

