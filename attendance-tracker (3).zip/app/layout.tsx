import type React from "react"
import "@/app/globals.css"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { AuthProvider } from "@/lib/auth-context"
import { AttendanceProvider } from "@/lib/attendance-context"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Zen Employee Attendance Tracker",
  description: "Track employee attendance with ease",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          <AuthProvider>
            <AttendanceProvider>
              <main className="min-h-screen bg-muted/40">{children}</main>
            </AttendanceProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'