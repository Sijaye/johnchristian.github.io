"use client"

import { useState, useEffect } from "react"
import { Calendar, Download, Plus, Trash2, Search, Clock, Edit, Users, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useRouter } from "next/navigation"
import { ActivityLog } from "@/components/activity-log"
import { MobileAttendanceView } from "@/components/mobile-attendance-view"
import { SyncStatus } from "@/components/sync-status"
import { SyncIndicator } from "@/components/sync-indicator"
import { useAuth } from "@/lib/auth-context"
import { useAttendanceData } from "@/lib/attendance-context"
import { useMobile } from "@/hooks/use-mobile"

export default function AttendanceTracker() {
  const router = useRouter()
  const { user, logout } = useAuth()
  const { employees, setEmployees, activities, addActivity, isLoading: dataLoading, refreshData } = useAttendanceData()
  const isMobile = useMobile()

  const currentYear = new Date().getFullYear()
  const currentMonth = new Date().getMonth() + 1

  const [year, setYear] = useState<number>(currentYear)
  const [month, setMonth] = useState<string>(currentMonth.toString())
  const [newEmployee, setNewEmployee] = useState({
    name: "",
    position: "",
    standardTime: "22:00", // Default 10 PM
    workSchedule: {
      monday: true,
      tuesday: true,
      wednesday: true,
      thursday: true,
      friday: true,
      saturday: false,
      sunday: false,
    },
  })
  const [editingEmployee, setEditingEmployee] = useState<any>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isActivityLogOpen, setIsActivityLogOpen] = useState(false)

  // Set up periodic data refresh to simulate real-time updates
  useEffect(() => {
    const refreshInterval = setInterval(() => {
      refreshData()
    }, 10000) // Refresh every 10 seconds

    return () => clearInterval(refreshInterval)
  }, [refreshData])

  // Generate dates for the selected month and year
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month, 0).getDate()
  }

  const getDateArray = () => {
    const daysInMonth = getDaysInMonth(year, Number.parseInt(month))
    return Array.from({ length: daysInMonth }, (_, i) => {
      const day = i + 1
      return new Date(year, Number.parseInt(month) - 1, day)
    })
  }

  const dateArray = getDateArray()

  // Format date as YYYY-MM-DD
  const formatDate = (date: Date) => {
    return date.toISOString().split("T")[0]
  }

  // Get day of week from date
  const getDayOfWeek = (date: Date) => {
    const days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]
    return days[date.getDay()]
  }

  // Check if employee is scheduled to work on a specific date
  const isScheduledToWork = (employee: any, date: Date) => {
    const dayOfWeek = getDayOfWeek(date)
    return employee.workSchedule[dayOfWeek]
  }

  // Check if employee is late based on check-in time
  const isLate = (checkInTime: string, standardTime: string) => {
    const [checkInHour, checkInMinute] = checkInTime.split(":").map(Number)
    const [standardHour, standardMinute] = standardTime.split(":").map(Number)

    if (checkInHour > standardHour) return true
    if (checkInHour === standardHour && checkInMinute > standardMinute) return true
    return false
  }

  // Handle attendance toggle
  const toggleAttendance = (employeeId: string, date: Date) => {
    const dateStr = formatDate(date)
    const employee = employees.find((emp: any) => emp.id === employeeId)

    if (!employee) return

    // Check if employee is scheduled to work on this date
    const scheduled = isScheduledToWork(employee, date)

    const updatedEmployees = employees.map((emp: any) => {
      if (emp.id === employeeId) {
        const currentAttendance = emp.attendance[dateStr] || { status: "" }
        let newAttendance

        if (currentAttendance.status === "") {
          // If empty, mark as present and check if late
          const now = new Date()
          const timeStr = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`

          // Check if late based on standard time
          const lateStatus = isLate(timeStr, emp.standardTime) ? "late" : "present"

          newAttendance = { status: lateStatus, time: timeStr }

          // Log activity
          addActivity({
            userId: user?.id || "unknown",
            userName: user?.name || "Unknown User",
            userEmail: user?.email || "unknown",
            action: lateStatus === "late" ? "marked-late" : "marked-present",
            employeeId: emp.id,
            employeeName: emp.name,
            date: dateStr,
            time: timeStr,
            timestamp: new Date().toISOString(),
          })
        } else if (currentAttendance.status === "present" || currentAttendance.status === "late") {
          // If present or late, change to absent (no time needed)
          newAttendance = { status: "absent" }

          // Log activity
          addActivity({
            userId: user?.id || "unknown",
            userName: user?.name || "Unknown User",
            userEmail: user?.email || "unknown",
            action: "marked-absent",
            employeeId: emp.id,
            employeeName: emp.name,
            date: dateStr,
            timestamp: new Date().toISOString(),
          })
        } else {
          // If absent, change to empty
          newAttendance = { status: "" }

          // Log activity
          addActivity({
            userId: user?.id || "unknown",
            userName: user?.name || "Unknown User",
            userEmail: user?.email || "unknown",
            action: "cleared-status",
            employeeId: emp.id,
            employeeName: emp.name,
            date: dateStr,
            timestamp: new Date().toISOString(),
          })
        }

        return {
          ...emp,
          attendance: {
            ...emp.attendance,
            [dateStr]: newAttendance,
          },
        }
      }
      return emp
    })

    setEmployees(updatedEmployees)
  }

  // Calculate attendance statistics
  const calculateStats = (employee: any) => {
    let presentCount = 0
    let lateCount = 0
    let absentCount = 0
    let scheduledDays = 0

    dateArray.forEach((date) => {
      const dateStr = formatDate(date)
      const attendance = employee.attendance[dateStr] || { status: "" }

      // Only count days the employee is scheduled to work
      if (isScheduledToWork(employee, date)) {
        scheduledDays++
        if (attendance.status === "present") presentCount++
        if (attendance.status === "late") lateCount++
        if (attendance.status === "absent") absentCount++
      }
    })

    const totalAttendance = presentCount + lateCount
    const presentPercentage = scheduledDays ? Math.round((totalAttendance / scheduledDays) * 100) : 0
    const absentPercentage = scheduledDays ? Math.round((absentCount / scheduledDays) * 100) : 0
    const latePercentage = totalAttendance ? Math.round((lateCount / totalAttendance) * 100) : 0

    return {
      presentCount,
      lateCount,
      absentCount,
      presentPercentage,
      absentPercentage,
      latePercentage,
      scheduledDays,
    }
  }

  // Add new employee
  const addEmployee = () => {
    if (!newEmployee.name.trim() || !newEmployee.position.trim()) {
      toast({
        title: "Error",
        description: "Name and position are required",
        variant: "destructive",
      })
      return
    }

    const newEmployeeData = {
      id: Date.now().toString(),
      name: newEmployee.name,
      position: newEmployee.position,
      standardTime: newEmployee.standardTime,
      workSchedule: newEmployee.workSchedule,
      attendance: {},
    }

    setEmployees([...employees, newEmployeeData])

    // Log activity
    addActivity({
      userId: user?.id || "unknown",
      userName: user?.name || "Unknown User",
      userEmail: user?.email || "unknown",
      action: "added-employee",
      employeeId: newEmployeeData.id,
      employeeName: newEmployeeData.name,
      timestamp: new Date().toISOString(),
    })

    setNewEmployee({
      name: "",
      position: "",
      standardTime: "22:00",
      workSchedule: {
        monday: true,
        tuesday: true,
        wednesday: true,
        thursday: true,
        friday: true,
        saturday: false,
        sunday: false,
      },
    })
    setIsAddDialogOpen(false)

    toast({
      title: "Success",
      description: `${newEmployee.name} has been added`,
    })
  }

  // Update employee
  const updateEmployee = () => {
    if (!editingEmployee) return

    const updatedEmployees = employees.map((emp: any) => (emp.id === editingEmployee.id ? editingEmployee : emp))

    setEmployees(updatedEmployees)

    // Log activity
    addActivity({
      userId: user?.id || "unknown",
      userName: user?.name || "Unknown User",
      userEmail: user?.email || "unknown",
      action: "updated-employee",
      employeeId: editingEmployee.id,
      employeeName: editingEmployee.name,
      timestamp: new Date().toISOString(),
    })

    setIsEditDialogOpen(false)
    setEditingEmployee(null)

    toast({
      title: "Success",
      description: `Employee details updated`,
    })
  }

  // Remove employee
  const removeEmployee = (id: string) => {
    const employeeToRemove = employees.find((emp: any) => emp.id === id)

    if (employeeToRemove) {
      setEmployees(employees.filter((emp: any) => emp.id !== id))

      // Log activity
      addActivity({
        userId: user?.id || "unknown",
        userName: user?.name || "Unknown User",
        userEmail: user?.email || "unknown",
        action: "removed-employee",
        employeeId: id,
        employeeName: employeeToRemove.name,
        timestamp: new Date().toISOString(),
      })

      toast({
        title: "Employee removed",
        description: "The employee has been removed from the tracker",
      })
    }
  }

  // Generate table
  const generateTable = () => {
    setIsLoading(true)
    // Refresh data from server/storage
    refreshData()
    // Simulate loading for better UX
    setTimeout(() => {
      setIsLoading(false)
    }, 500)
  }

  // Download as CSV
  const downloadCSV = () => {
    const csv = []

    // Header row
    const header = ["Name", "Position", "Standard Time", "Present", "Late", "Absent", "% Present", "% Absent", "% Late"]
    dateArray.forEach((date) => {
      header.push(`${date.toLocaleDateString()} (Status)`)
      header.push(`${date.toLocaleDateString()} (Time)`)
      header.push(`${date.toLocaleDateString()} (Scheduled)`)
    })
    csv.push(header.join(","))

    // Data rows
    filteredEmployees.forEach((emp: any) => {
      const stats = calculateStats(emp)
      const row = [
        emp.name,
        emp.position,
        emp.standardTime,
        stats.presentCount.toString(),
        stats.lateCount.toString(),
        stats.absentCount.toString(),
        `${stats.presentPercentage}%`,
        `${stats.absentPercentage}%`,
        `${stats.latePercentage}%`,
      ]

      dateArray.forEach((date) => {
        const dateStr = formatDate(date)
        const attendance = emp.attendance[dateStr] || { status: "" }
        const scheduled = isScheduledToWork(emp, date)

        let status = ""
        if (attendance.status === "present") status = "P"
        else if (attendance.status === "late") status = "L"
        else if (attendance.status === "absent") status = "A"

        row.push(status)
        row.push(attendance.time || "")
        row.push(scheduled ? "Yes" : "No")
      })

      csv.push(row.join(","))
    })

    // Create and download file
    const csvContent = csv.join("\n")
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `Zen_Attendance_${year}_${month}.csv`
    link.click()
    URL.revokeObjectURL(url)

    toast({
      title: "CSV Downloaded",
      description: "Your attendance data has been downloaded",
    })

    // Log activity
    addActivity({
      userId: user?.id || "unknown",
      userName: user?.name || "Unknown User",
      userEmail: user?.email || "unknown",
      action: "downloaded-csv",
      timestamp: new Date().toISOString(),
    })
  }

  // Filter employees based on search term
  const filteredEmployees = employees.filter(
    (emp: any) =>
      emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.position.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Handle logout
  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <SyncStatus />

      <Card className="shadow-lg">
        <CardHeader className="bg-primary text-primary-foreground">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex flex-col">
              <CardTitle className="text-2xl flex items-center">
                <Calendar className="mr-2" /> Zen Employee Attendance Tracker
              </CardTitle>
              <div className="mt-1">
                <SyncIndicator />
              </div>
            </div>
            <div className="flex flex-col sm:flex-row items-center gap-2">
              <div className="flex items-center mr-4 text-sm">
                <span className="mr-2">Logged in as:</span>
                <Badge variant="secondary" className="font-normal">
                  {user?.name} ({user?.email})
                </Badge>
              </div>
              <div className="flex flex-wrap gap-2">
                <Dialog open={isActivityLogOpen} onOpenChange={setIsActivityLogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="bg-primary-foreground text-primary">
                      <Users className="mr-2 h-4 w-4" /> Activity Log
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Activity Log</DialogTitle>
                    </DialogHeader>
                    <ActivityLog activities={activities} />
                  </DialogContent>
                </Dialog>
                <Button
                  variant="outline"
                  size="sm"
                  className="bg-primary-foreground text-primary"
                  onClick={handleLogout}
                >
                  <LogOut className="mr-2 h-4 w-4" /> Logout
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <div>
              <Label htmlFor="year">Year</Label>
              <Input
                id="year"
                type="number"
                value={year}
                onChange={(e) => setYear(Number.parseInt(e.target.value))}
                min="2000"
                max="2100"
              />
            </div>
            <div>
              <Label htmlFor="month">Month</Label>
              <Select value={month} onValueChange={setMonth}>
                <SelectTrigger id="month">
                  <SelectValue placeholder="Select month" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">January</SelectItem>
                  <SelectItem value="2">February</SelectItem>
                  <SelectItem value="3">March</SelectItem>
                  <SelectItem value="4">April</SelectItem>
                  <SelectItem value="5">May</SelectItem>
                  <SelectItem value="6">June</SelectItem>
                  <SelectItem value="7">July</SelectItem>
                  <SelectItem value="8">August</SelectItem>
                  <SelectItem value="9">September</SelectItem>
                  <SelectItem value="10">October</SelectItem>
                  <SelectItem value="11">November</SelectItem>
                  <SelectItem value="12">December</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="search">Search</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="Search employees..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="flex items-end">
              <Button onClick={generateTable} className="w-full" disabled={isLoading || dataLoading}>
                {isLoading || dataLoading ? "Loading..." : "Refresh Data"}
              </Button>
            </div>
            <div className="flex items-end">
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full flex items-center">
                    <Plus className="mr-2 h-4 w-4" /> Add Employee
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Add New Employee</DialogTitle>
                  </DialogHeader>
                  <Tabs defaultValue="details">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="details">Details</TabsTrigger>
                      <TabsTrigger value="schedule">Work Schedule</TabsTrigger>
                    </TabsList>
                    <TabsContent value="details" className="space-y-4 pt-4">
                      <div className="grid gap-2">
                        <Label htmlFor="name">Name</Label>
                        <Input
                          id="name"
                          value={newEmployee.name}
                          onChange={(e) => setNewEmployee({ ...newEmployee, name: e.target.value })}
                          placeholder="Enter employee name"
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="position">Position</Label>
                        <Input
                          id="position"
                          value={newEmployee.position}
                          onChange={(e) => setNewEmployee({ ...newEmployee, position: e.target.value })}
                          placeholder="Enter employee position"
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="standardTime">Standard Check-in Time</Label>
                        <Input
                          id="standardTime"
                          type="time"
                          value={newEmployee.standardTime}
                          onChange={(e) => setNewEmployee({ ...newEmployee, standardTime: e.target.value })}
                        />
                        <p className="text-xs text-muted-foreground">
                          Employees checking in after this time will be marked as late
                        </p>
                      </div>
                    </TabsContent>
                    <TabsContent value="schedule" className="space-y-4 pt-4">
                      <div className="space-y-4">
                        <Label>Work Days</Label>
                        <div className="grid grid-cols-2 gap-4">
                          {Object.entries(newEmployee.workSchedule).map(([day, isWorking]) => (
                            <div key={day} className="flex items-center space-x-2">
                              <Checkbox
                                id={`new-${day}`}
                                checked={isWorking}
                                onCheckedChange={(checked) =>
                                  setNewEmployee({
                                    ...newEmployee,
                                    workSchedule: {
                                      ...newEmployee.workSchedule,
                                      [day]: !!checked,
                                    },
                                  })
                                }
                              />
                              <Label htmlFor={`new-${day}`} className="capitalize">
                                {day}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                  <DialogFooter className="mt-4">
                    <Button onClick={addEmployee}>Add Employee</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="flex justify-end mb-4">
            <Button variant="outline" onClick={downloadCSV} className="flex items-center">
              <Download className="mr-2 h-4 w-4" /> Download CSV
            </Button>
          </div>

          {isMobile ? (
            <MobileAttendanceView
              employees={filteredEmployees}
              dateArray={dateArray}
              formatDate={formatDate}
              getDayOfWeek={getDayOfWeek}
              isScheduledToWork={isScheduledToWork}
              toggleAttendance={toggleAttendance}
              calculateStats={calculateStats}
              removeEmployee={removeEmployee}
              updateEmployee={updateEmployee}
              editingEmployee={editingEmployee}
              setEditingEmployee={setEditingEmployee}
              isEditDialogOpen={isEditDialogOpen}
              setIsEditDialogOpen={setIsEditDialogOpen}
            />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="sticky left-0 bg-background z-10">Name</TableHead>
                    <TableHead className="sticky left-[100px] bg-background z-10">Position</TableHead>
                    <TableHead className="text-center whitespace-nowrap">Standard Time</TableHead>
                    <TableHead className="text-center">Present</TableHead>
                    <TableHead className="text-center">Late</TableHead>
                    <TableHead className="text-center">Absent</TableHead>
                    <TableHead className="text-center">% Present</TableHead>
                    <TableHead className="text-center">% Absent</TableHead>
                    {dateArray.map((date) => (
                      <TableHead key={date.toString()} className="text-center whitespace-nowrap">
                        {date.toLocaleDateString(undefined, { day: "numeric", month: "short" })}
                        <div className="text-xs text-muted-foreground capitalize">{getDayOfWeek(date)}</div>
                      </TableHead>
                    ))}
                    <TableHead className="text-center">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEmployees.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9 + dateArray.length} className="text-center py-8 text-muted-foreground">
                        No employees found. Add an employee to get started.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredEmployees.map((employee: any) => {
                      const stats = calculateStats(employee)
                      return (
                        <TableRow key={employee.id}>
                          <TableCell className="font-medium sticky left-0 bg-background z-10">
                            {employee.name}
                          </TableCell>
                          <TableCell className="sticky left-[100px] bg-background z-10">{employee.position}</TableCell>
                          <TableCell className="text-center whitespace-nowrap">
                            <div className="flex items-center justify-center">
                              <Clock className="h-3 w-3 mr-1" />
                              {employee.standardTime}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">{stats.presentCount + stats.lateCount}</TableCell>
                          <TableCell className="text-center">{stats.lateCount}</TableCell>
                          <TableCell className="text-center">{stats.absentCount}</TableCell>
                          <TableCell className="text-center">
                            <Badge variant="success">{stats.presentPercentage}%</Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant="destructive">{stats.absentPercentage}%</Badge>
                          </TableCell>
                          {dateArray.map((date) => {
                            const dateStr = formatDate(date)
                            const attendance = employee.attendance[dateStr] || { status: "" }
                            const scheduled = isScheduledToWork(employee, date)

                            // Apply different styling for non-scheduled days
                            const cellClass = scheduled
                              ? "text-center cursor-pointer hover:bg-muted transition-colors"
                              : "text-center bg-muted/30"

                            return (
                              <TableCell
                                key={`${employee.id}-${dateStr}`}
                                className={cellClass}
                                onClick={scheduled ? () => toggleAttendance(employee.id, date) : undefined}
                              >
                                {!scheduled && <span className="text-xs text-muted-foreground">Off</span>}
                                {scheduled && attendance.status === "present" && (
                                  <div className="flex flex-col items-center">
                                    <Badge variant="success" className="w-8 mb-1">
                                      P
                                    </Badge>
                                    {attendance.time && (
                                      <span className="text-xs text-muted-foreground">{attendance.time}</span>
                                    )}
                                  </div>
                                )}
                                {scheduled && attendance.status === "late" && (
                                  <div className="flex flex-col items-center">
                                    <Badge variant="warning" className="w-8 mb-1">
                                      L
                                    </Badge>
                                    {attendance.time && (
                                      <span className="text-xs text-muted-foreground">{attendance.time}</span>
                                    )}
                                  </div>
                                )}
                                {scheduled && attendance.status === "absent" && (
                                  <Badge variant="destructive" className="w-8">
                                    A
                                  </Badge>
                                )}
                                {scheduled && attendance.status === "" && (
                                  <Badge variant="outline" className="w-8">
                                    -
                                  </Badge>
                                )}
                              </TableCell>
                            )
                          })}
                          <TableCell className="text-center">
                            <div className="flex items-center justify-center space-x-2">
                              <Dialog
                                open={isEditDialogOpen && editingEmployee?.id === employee.id}
                                onOpenChange={(open) => {
                                  setIsEditDialogOpen(open)
                                  if (open) setEditingEmployee(employee)
                                  else setEditingEmployee(null)
                                }}
                              >
                                <DialogTrigger asChild>
                                  <Button variant="outline" size="sm">
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="max-w-md">
                                  <DialogHeader>
                                    <DialogTitle>Edit Employee</DialogTitle>
                                  </DialogHeader>
                                  {editingEmployee && (
                                    <Tabs defaultValue="details">
                                      <TabsList className="grid w-full grid-cols-2">
                                        <TabsTrigger value="details">Details</TabsTrigger>
                                        <TabsTrigger value="schedule">Work Schedule</TabsTrigger>
                                      </TabsList>
                                      <TabsContent value="details" className="space-y-4 pt-4">
                                        <div className="grid gap-2">
                                          <Label htmlFor="edit-name">Name</Label>
                                          <Input
                                            id="edit-name"
                                            value={editingEmployee.name}
                                            onChange={(e) =>
                                              setEditingEmployee({
                                                ...editingEmployee,
                                                name: e.target.value,
                                              })
                                            }
                                          />
                                        </div>
                                        <div className="grid gap-2">
                                          <Label htmlFor="edit-position">Position</Label>
                                          <Input
                                            id="edit-position"
                                            value={editingEmployee.position}
                                            onChange={(e) =>
                                              setEditingEmployee({
                                                ...editingEmployee,
                                                position: e.target.value,
                                              })
                                            }
                                          />
                                        </div>
                                        <div className="grid gap-2">
                                          <Label htmlFor="edit-standardTime">Standard Check-in Time</Label>
                                          <Input
                                            id="edit-standardTime"
                                            type="time"
                                            value={editingEmployee.standardTime}
                                            onChange={(e) =>
                                              setEditingEmployee({
                                                ...editingEmployee,
                                                standardTime: e.target.value,
                                              })
                                            }
                                          />
                                          <p className="text-xs text-muted-foreground">
                                            Employees checking in after this time will be marked as late
                                          </p>
                                        </div>
                                      </TabsContent>
                                      <TabsContent value="schedule" className="space-y-4 pt-4">
                                        <div className="space-y-4">
                                          <Label>Work Days</Label>
                                          <div className="grid grid-cols-2 gap-4">
                                            {Object.entries(editingEmployee.workSchedule).map(([day, isWorking]) => (
                                              <div key={day} className="flex items-center space-x-2">
                                                <Checkbox
                                                  id={`edit-${day}`}
                                                  checked={isWorking}
                                                  onCheckedChange={(checked) =>
                                                    setEditingEmployee({
                                                      ...editingEmployee,
                                                      workSchedule: {
                                                        ...editingEmployee.workSchedule,
                                                        [day]: !!checked,
                                                      },
                                                    })
                                                  }
                                                />
                                                <Label htmlFor={`edit-${day}`} className="capitalize">
                                                  {day}
                                                </Label>
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      </TabsContent>
                                    </Tabs>
                                  )}
                                  <DialogFooter className="mt-4">
                                    <Button onClick={updateEmployee}>Update Employee</Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              <Button variant="destructive" size="sm" onClick={() => removeEmployee(employee.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      <Toaster />
    </div>
  )
}

