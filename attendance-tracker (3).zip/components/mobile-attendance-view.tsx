"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp, Clock, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"

// This component provides a mobile-optimized view of the same attendance data
// It's just a different UI for smaller screens - the data is shared with the desktop view
interface MobileAttendanceViewProps {
  employees: any[]
  dateArray: Date[]
  formatDate: (date: Date) => string
  getDayOfWeek: (date: Date) => string
  isScheduledToWork: (employee: any, date: Date) => boolean
  toggleAttendance: (employeeId: string, date: Date) => void
  calculateStats: (employee: any) => any
  removeEmployee: (id: string) => void
  updateEmployee: () => void
  editingEmployee: any
  setEditingEmployee: (employee: any) => void
  isEditDialogOpen: boolean
  setIsEditDialogOpen: (isOpen: boolean) => void
}

export function MobileAttendanceView({
  employees,
  dateArray,
  formatDate,
  getDayOfWeek,
  isScheduledToWork,
  toggleAttendance,
  calculateStats,
  removeEmployee,
  updateEmployee,
  editingEmployee,
  setEditingEmployee,
  isEditDialogOpen,
  setIsEditDialogOpen,
}: MobileAttendanceViewProps) {
  const [expandedDates, setExpandedDates] = useState<Record<string, boolean>>({})

  // Toggle expanded dates for an employee
  const toggleExpandDates = (employeeId: string) => {
    setExpandedDates((prev) => ({
      ...prev,
      [employeeId]: !prev[employeeId],
    }))
  }

  return (
    <div className="space-y-4">
      {employees.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8 text-muted-foreground">
            No employees found. Add an employee to get started.
          </CardContent>
        </Card>
      ) : (
        employees.map((employee) => {
          const stats = calculateStats(employee)
          const isExpanded = expandedDates[employee.id] || false

          return (
            <Card key={employee.id} className="overflow-hidden">
              <CardHeader className="p-4 pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{employee.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">{employee.position}</p>
                  </div>
                  <div className="flex space-x-2">
                    <Dialog
                      open={isEditDialogOpen && editingEmployee?.id === employee.id}
                      onOpenChange={(open) => {
                        setIsEditDialogOpen(open)
                        if (open) setEditingEmployee(employee)
                        else setEditingEmployee(null)
                      }}
                    >
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md">
                        <DialogHeader>
                          <DialogTitle>Edit Employee</DialogTitle>
                        </DialogHeader>
                        {editingEmployee && (
                          <Tabs defaultValue="details">
                            <TabsList className="grid w-full grid-cols-2">
                              <TabsTrigger value="details">Details</TabsTrigger>
                              <TabsTrigger value="schedule">Work Schedule</TabsTrigger>
                            </TabsList>
                            <TabsContent value="details" className="space-y-4 pt-4">
                              <div className="grid gap-2">
                                <Label htmlFor="edit-name">Name</Label>
                                <Input
                                  id="edit-name"
                                  value={editingEmployee.name}
                                  onChange={(e) =>
                                    setEditingEmployee({
                                      ...editingEmployee,
                                      name: e.target.value,
                                    })
                                  }
                                />
                              </div>
                              <div className="grid gap-2">
                                <Label htmlFor="edit-position">Position</Label>
                                <Input
                                  id="edit-position"
                                  value={editingEmployee.position}
                                  onChange={(e) =>
                                    setEditingEmployee({
                                      ...editingEmployee,
                                      position: e.target.value,
                                    })
                                  }
                                />
                              </div>
                              <div className="grid gap-2">
                                <Label htmlFor="edit-standardTime">Standard Check-in Time</Label>
                                <Input
                                  id="edit-standardTime"
                                  type="time"
                                  value={editingEmployee.standardTime}
                                  onChange={(e) =>
                                    setEditingEmployee({
                                      ...editingEmployee,
                                      standardTime: e.target.value,
                                    })
                                  }
                                />
                                <p className="text-xs text-muted-foreground">
                                  Employees checking in after this time will be marked as late
                                </p>
                              </div>
                            </TabsContent>
                            <TabsContent value="schedule" className="space-y-4 pt-4">
                              <div className="space-y-4">
                                <Label>Work Days</Label>
                                <div className="grid grid-cols-2 gap-4">
                                  {Object.entries(editingEmployee.workSchedule).map(([day, isWorking]) => (
                                    <div key={day} className="flex items-center space-x-2">
                                      <Checkbox
                                        id={`edit-${day}`}
                                        checked={isWorking}
                                        onCheckedChange={(checked) =>
                                          setEditingEmployee({
                                            ...editingEmployee,
                                            workSchedule: {
                                              ...editingEmployee.workSchedule,
                                              [day]: !!checked,
                                            },
                                          })
                                        }
                                      />
                                      <Label htmlFor={`edit-${day}`} className="capitalize">
                                        {day}
                                      </Label>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </TabsContent>
                          </Tabs>
                        )}
                        <DialogFooter className="mt-4">
                          <Button onClick={updateEmployee}>Update Employee</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                    <Button variant="destructive" size="sm" onClick={() => removeEmployee(employee.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="flex items-center space-x-2 mb-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{employee.standardTime}</span>
                </div>

                <div className="grid grid-cols-3 gap-2 mb-4">
                  <div className="text-center">
                    <div className="text-sm font-medium">Present</div>
                    <div className="text-lg">{stats.presentCount + stats.lateCount}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">Late</div>
                    <div className="text-lg">{stats.lateCount}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-medium">Absent</div>
                    <div className="text-lg">{stats.absentCount}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="text-center">
                    <Badge variant="success" className="w-full">
                      {stats.presentPercentage}% Present
                    </Badge>
                  </div>
                  <div className="text-center">
                    <Badge variant="destructive" className="w-full">
                      {stats.absentPercentage}% Absent
                    </Badge>
                  </div>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full flex items-center justify-center"
                  onClick={() => toggleExpandDates(employee.id)}
                >
                  {isExpanded ? (
                    <>
                      <ChevronUp className="h-4 w-4 mr-2" /> Hide Attendance
                    </>
                  ) : (
                    <>
                      <ChevronDown className="h-4 w-4 mr-2" /> View Attendance
                    </>
                  )}
                </Button>

                {isExpanded && (
                  <div className="mt-4">
                    <Accordion type="multiple" className="w-full">
                      {dateArray.map((date) => {
                        const dateStr = formatDate(date)
                        const attendance = employee.attendance[dateStr] || { status: "" }
                        const scheduled = isScheduledToWork(employee, date)
                        const dayOfWeek = getDayOfWeek(date)

                        return (
                          <AccordionItem key={dateStr} value={dateStr}>
                            <AccordionTrigger className="py-2">
                              <div className="flex items-center justify-between w-full pr-4">
                                <div className="flex items-center">
                                  <span className="font-medium">
                                    {date.toLocaleDateString(undefined, { day: "numeric", month: "short" })}
                                  </span>
                                  <span className="text-xs text-muted-foreground ml-2 capitalize">{dayOfWeek}</span>
                                </div>
                                <div>
                                  {!scheduled && <span className="text-xs text-muted-foreground">Off</span>}
                                  {scheduled && attendance.status === "present" && (
                                    <Badge variant="success">Present</Badge>
                                  )}
                                  {scheduled && attendance.status === "late" && <Badge variant="warning">Late</Badge>}
                                  {scheduled && attendance.status === "absent" && (
                                    <Badge variant="destructive">Absent</Badge>
                                  )}
                                  {scheduled && attendance.status === "" && <Badge variant="outline">Not Marked</Badge>}
                                </div>
                              </div>
                            </AccordionTrigger>
                            <AccordionContent>
                              {scheduled ? (
                                <div className="py-2">
                                  {attendance.time && (
                                    <div className="text-sm mb-2">
                                      Check-in time: <span className="font-medium">{attendance.time}</span>
                                    </div>
                                  )}
                                  <div className="flex space-x-2">
                                    <Button
                                      size="sm"
                                      variant={attendance.status === "present" ? "default" : "outline"}
                                      className="flex-1"
                                      onClick={() => {
                                        if (attendance.status !== "present") {
                                          toggleAttendance(employee.id, date)
                                        }
                                      }}
                                    >
                                      Present
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant={attendance.status === "late" ? "default" : "outline"}
                                      className="flex-1"
                                      onClick={() => {
                                        if (attendance.status !== "late") {
                                          // First mark as present, then as late
                                          if (attendance.status === "") {
                                            toggleAttendance(employee.id, date)
                                          }
                                          toggleAttendance(employee.id, date)
                                        }
                                      }}
                                    >
                                      Late
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant={attendance.status === "absent" ? "default" : "outline"}
                                      className="flex-1"
                                      onClick={() => {
                                        if (attendance.status !== "absent") {
                                          // If present or late, toggle once to absent
                                          // If not marked, toggle twice (to present then to absent)
                                          if (attendance.status === "") {
                                            toggleAttendance(employee.id, date)
                                          }
                                          toggleAttendance(employee.id, date)
                                        }
                                      }}
                                    >
                                      Absent
                                    </Button>
                                  </div>
                                </div>
                              ) : (
                                <div className="py-2 text-sm text-muted-foreground">
                                  Employee is not scheduled to work on this day.
                                </div>
                              )}
                            </AccordionContent>
                          </AccordionItem>
                        )
                      })}
                    </Accordion>
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })
      )}
    </div>
  )
}

