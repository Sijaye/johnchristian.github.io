// The Activity Log shows actions from all users across all devices
// This provides a unified view of changes made to the attendance data
// regardless of whether users are on mobile or desktop

import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"

interface Activity {
  userId: string
  userName: string
  userEmail?: string
  action: string
  employeeId?: string
  employeeName?: string
  date?: string
  time?: string
  timestamp: string
}

interface ActivityLogProps {
  activities: Activity[]
}

export function ActivityLog({ activities }: ActivityLogProps) {
  // Function to format timestamp
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleString()
  }

  // Function to get action description
  const getActionDescription = (activity: Activity) => {
    switch (activity.action) {
      case "marked-present":
        return `marked ${activity.employeeName} as present on ${activity.date} at ${activity.time}`
      case "marked-late":
        return `marked ${activity.employeeName} as late on ${activity.date} at ${activity.time}`
      case "marked-absent":
        return `marked ${activity.employeeName} as absent on ${activity.date}`
      case "cleared-status":
        return `cleared attendance status for ${activity.employeeName} on ${activity.date}`
      case "added-employee":
        return `added new employee: ${activity.employeeName}`
      case "updated-employee":
        return `updated employee details for ${activity.employeeName}`
      case "removed-employee":
        return `removed employee: ${activity.employeeName}`
      case "downloaded-csv":
        return `downloaded attendance data as CSV`
      default:
        return activity.action
    }
  }

  // Function to get badge variant based on action
  const getBadgeVariant = (action: string) => {
    switch (action) {
      case "marked-present":
        return "success"
      case "marked-late":
        return "warning"
      case "marked-absent":
        return "destructive"
      case "added-employee":
        return "success"
      case "updated-employee":
        return "secondary"
      case "removed-employee":
        return "destructive"
      default:
        return "outline"
    }
  }

  return (
    <ScrollArea className="h-[500px] pr-4">
      {activities.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">No activity recorded yet</div>
      ) : (
        <div className="space-y-4">
          {activities
            .slice()
            .reverse()
            .map((activity, index) => (
              <Card key={index} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex flex-col space-y-2">
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">
                        {activity.userName}
                        {activity.userEmail ? ` (${activity.userEmail})` : ""}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{formatTimestamp(activity.timestamp)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={getBadgeVariant(activity.action)} className="capitalize">
                        {activity.action.replace(/-/g, " ")}
                      </Badge>
                      <span>{getActionDescription(activity)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
        </div>
      )}
    </ScrollArea>
  )
}

