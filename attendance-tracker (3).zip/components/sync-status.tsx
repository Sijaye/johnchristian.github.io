"use client"

import { useState, useEffect } from "react"
import { AlertCircle, CloudOff, Cloud } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"

export function SyncStatus() {
  const [showAlert, setShowAlert] = useState(true)
  const [isOnline, setIsOnline] = useState(true)

  useEffect(() => {
    // Check online status
    const handleOnlineStatus = () => {
      setIsOnline(navigator.onLine)
    }

    window.addEventListener("online", handleOnlineStatus)
    window.addEventListener("offline", handleOnlineStatus)

    // Initial check
    handleOnlineStatus()

    return () => {
      window.removeEventListener("online", handleOnlineStatus)
      window.removeEventListener("offline", handleOnlineStatus)
    }
  }, [])

  if (!showAlert) return null

  return (
    <Alert className="mb-4">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle className="flex items-center">
        {isOnline ? (
          <>
            <Cloud className="h-4 w-4 mr-2 text-green-500" />
            Demo Mode: Simulated Cloud Sync
          </>
        ) : (
          <>
            <CloudOff className="h-4 w-4 mr-2 text-red-500" />
            Offline Mode: Local Storage Only
          </>
        )}
      </AlertTitle>
      <AlertDescription className="mt-2">
        <p className="mb-2">
          This is a demonstration of how a multi-device attendance tracker would work. In a production environment, this
          would connect to a real database server to synchronize data across all devices.
        </p>
        <p className="mb-2">
          Currently, data is stored in your browser's local storage. For a true multi-device experience, this
          application would need to be deployed with a backend server and database.
        </p>
        <div className="flex justify-end mt-2">
          <Button variant="outline" size="sm" onClick={() => setShowAlert(false)}>
            Dismiss
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  )
}

