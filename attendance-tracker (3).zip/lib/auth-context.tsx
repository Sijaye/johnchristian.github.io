"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { cloudStorage } from "./cloud-storage"

interface User {
  id: string
  name: string
  email: string
}

interface UserCredentials extends User {
  password: string
}

interface AuthContextType {
  user: User | null
  register: (userData: UserCredentials) => Promise<boolean>
  login: (email: string, password: string) => Promise<User | null>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Helper to store session in both localStorage and cookies for cross-device access
const storeSessionData = (user: User, token: string) => {
  // Store in localStorage for current browser session
  localStorage.setItem("attendanceUser", JSON.stringify(user))
  localStorage.setItem("attendanceToken", token)

  // Store in cookies for cross-device access (in a real app, this would be HTTP-only cookies)
  document.cookie = `attendanceUserId=${user.id}; path=/; max-age=86400; SameSite=Strict`
  document.cookie = `attendanceToken=${token}; path=/; max-age=86400; SameSite=Strict`
}

// Helper to clear session data
const clearSessionData = () => {
  localStorage.removeItem("attendanceUser")
  localStorage.removeItem("attendanceToken")

  // Clear cookies
  document.cookie = "attendanceUserId=; path=/; max-age=0"
  document.cookie = "attendanceToken=; path=/; max-age=0"
}

// Helper to get cookie value
const getCookie = (name: string): string | null => {
  const value = `; ${document.cookie}`
  const parts = value.split(`; ${name}=`)
  if (parts.length === 2) return parts.pop()?.split(";").shift() || null
  return null
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Load user from localStorage or cookies on initial render
  useEffect(() => {
    const loadUser = async () => {
      setIsLoading(true)
      try {
        // First try localStorage (for same browser session)
        const savedUser = localStorage.getItem("attendanceUser")
        const savedToken = localStorage.getItem("attendanceToken")

        if (savedUser && savedToken) {
          const parsedUser = JSON.parse(savedUser) as User
          // Validate session with cloud storage
          const isValid = await cloudStorage.validateSession(parsedUser.id, savedToken)

          if (isValid) {
            setUser(parsedUser)
            setIsLoading(false)
            return
          }
        }

        // If localStorage fails, try cookies (for cross-device access)
        const userId = getCookie("attendanceUserId")
        const token = getCookie("attendanceToken")

        if (userId && token) {
          // Validate session with cloud storage
          const isValid = await cloudStorage.validateSession(userId, token)

          if (isValid) {
            // Get user data from cloud storage
            const users = (await cloudStorage.get("attendanceUsers")) || []
            const foundUser = users.find((u: any) => u.id === userId)

            if (foundUser) {
              const { password, ...userWithoutPassword } = foundUser
              setUser(userWithoutPassword)

              // Update localStorage for convenience
              localStorage.setItem("attendanceUser", JSON.stringify(userWithoutPassword))
              localStorage.setItem("attendanceToken", token)
            }
          }
        }
      } catch (error) {
        console.error("Error loading user:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadUser()
  }, [])

  const register = async (userData: UserCredentials): Promise<boolean> => {
    try {
      // Register user in cloud storage
      const success = await cloudStorage.registerUser(userData)
      return success
    } catch (error) {
      console.error("Error registering user:", error)
      return false
    }
  }

  const login = async (email: string, password: string): Promise<User | null> => {
    try {
      // Authenticate with cloud storage
      const authenticatedUser = await cloudStorage.authenticateUser(email, password)

      if (authenticatedUser) {
        // Generate and store session token
        const token = cloudStorage.generateSessionToken(authenticatedUser.id)
        await cloudStorage.storeSession(authenticatedUser.id, token)

        // Store session data for cross-device access
        storeSessionData(authenticatedUser, token)

        // Update state
        setUser(authenticatedUser)
        return authenticatedUser
      }

      return null
    } catch (error) {
      console.error("Error logging in:", error)
      return null
    }
  }

  const logout = async () => {
    if (user) {
      try {
        // Clear session in cloud storage
        await cloudStorage.clearSession(user.id)

        // Clear local session data
        clearSessionData()

        // Update state
        setUser(null)
      } catch (error) {
        console.error("Error logging out:", error)
      }
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        register,
        login,
        logout,
        isLoading,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

