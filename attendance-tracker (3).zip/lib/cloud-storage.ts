// This simulates a cloud database service that would be accessible from any device
// In a real application, this would be replaced with actual API calls to a backend server

// Type definitions
type StorageData = {
  [key: string]: any
}

// Simulated cloud database
class CloudStorage {
  private static instance: CloudStorage
  private data: StorageData = {}
  private listeners: { [key: string]: ((data: any) => void)[] } = {}

  private constructor() {
    // Initialize with data from localStorage if available
    try {
      // Load initial data from localStorage for development purposes
      const keys = ["attendanceUsers", "attendanceEmployees", "attendanceActivities"]
      keys.forEach((key) => {
        const storedData = localStorage.getItem(key)
        if (storedData) {
          this.data[key] = JSON.parse(storedData)
        } else {
          this.data[key] =
            key === "attendanceUsers"
              ? []
              : key === "attendanceEmployees"
                ? []
                : key === "attendanceActivities"
                  ? []
                  : null
        }
      })
    } catch (error) {
      console.error("Error initializing cloud storage:", error)
    }

    // Set up periodic sync to localStorage (for development purposes only)
    setInterval(() => {
      Object.keys(this.data).forEach((key) => {
        localStorage.setItem(key, JSON.stringify(this.data[key]))
      })
    }, 1000)
  }

  public static getInstance(): CloudStorage {
    if (!CloudStorage.instance) {
      CloudStorage.instance = new CloudStorage()
    }
    return CloudStorage.instance
  }

  // Get data from cloud
  public async get(key: string): Promise<any> {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 100))
    return this.data[key] || null
  }

  // Set data in cloud
  public async set(key: string, value: any): Promise<void> {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 100))
    this.data[key] = value

    // Notify listeners
    if (this.listeners[key]) {
      this.listeners[key].forEach((listener) => listener(value))
    }

    // Also update localStorage for persistence during development
    localStorage.setItem(key, JSON.stringify(value))
  }

  // Subscribe to changes
  public subscribe(key: string, callback: (data: any) => void): () => void {
    if (!this.listeners[key]) {
      this.listeners[key] = []
    }
    this.listeners[key].push(callback)

    // Return unsubscribe function
    return () => {
      this.listeners[key] = this.listeners[key].filter((cb) => cb !== callback)
    }
  }

  // Check if user exists by email
  public async getUserByEmail(email: string): Promise<any> {
    const users = (await this.get("attendanceUsers")) || []
    return users.find((user: any) => user.email === email) || null
  }

  // Authenticate user
  public async authenticateUser(email: string, password: string): Promise<any> {
    const users = (await this.get("attendanceUsers")) || []
    const user = users.find((user: any) => user.email === email && user.password === password)
    if (user) {
      const { password, ...userWithoutPassword } = user
      return userWithoutPassword
    }
    return null
  }

  // Register new user
  public async registerUser(userData: any): Promise<boolean> {
    const users = (await this.get("attendanceUsers")) || []

    // Check if email already exists
    if (users.some((user: any) => user.email === userData.email)) {
      return false
    }

    // Add new user
    const updatedUsers = [...users, userData]
    await this.set("attendanceUsers", updatedUsers)
    return true
  }

  // Generate a session token (in a real app, this would be a JWT or similar)
  public generateSessionToken(userId: string): string {
    return `session_${userId}_${Date.now()}`
  }

  // Store session
  public async storeSession(userId: string, token: string): Promise<void> {
    const sessions = (await this.get("attendanceSessions")) || {}
    sessions[userId] = { token, timestamp: Date.now() }
    await this.set("attendanceSessions", sessions)
  }

  // Validate session
  public async validateSession(userId: string, token: string): Promise<boolean> {
    const sessions = (await this.get("attendanceSessions")) || {}
    const session = sessions[userId]
    if (!session) return false

    // Check if token matches and is not expired (24 hour expiry)
    const isValid = session.token === token && Date.now() - session.timestamp < 24 * 60 * 60 * 1000
    return isValid
  }

  // Clear session
  public async clearSession(userId: string): Promise<void> {
    const sessions = (await this.get("attendanceSessions")) || {}
    delete sessions[userId]
    await this.set("attendanceSessions", sessions)
  }
}

export const cloudStorage = CloudStorage.getInstance()

