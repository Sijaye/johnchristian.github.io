"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { cloudStorage } from "./cloud-storage"

interface Activity {
  userId: string
  userName: string
  userEmail?: string
  action: string
  employeeId?: string
  employeeName?: string
  date?: string
  time?: string
  timestamp: string
}

interface AttendanceContextType {
  employees: any[]
  setEmployees: (employees: any[]) => Promise<void>
  activities: Activity[]
  addActivity: (activity: Activity) => Promise<void>
  isLoading: boolean
  refreshData: () => Promise<void>
}

const AttendanceContext = createContext<AttendanceContextType | undefined>(undefined)

export function AttendanceProvider({ children }: { children: ReactNode }) {
  const [employees, setEmployeesState] = useState<any[]>([])
  const [activities, setActivities] = useState<Activity[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Load data from cloud storage on initial render
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true)
      try {
        const savedEmployees = await cloudStorage.get("attendanceEmployees")
        const savedActivities = await cloudStorage.get("attendanceActivities")

        if (savedEmployees) {
          setEmployeesState(savedEmployees)
        }

        if (savedActivities) {
          setActivities(savedActivities)
        }
      } catch (error) {
        console.error("Error loading data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()

    // Subscribe to changes in cloud storage
    const unsubscribeEmployees = cloudStorage.subscribe("attendanceEmployees", (data) => {
      setEmployeesState(data || [])
    })

    const unsubscribeActivities = cloudStorage.subscribe("attendanceActivities", (data) => {
      setActivities(data || [])
    })

    return () => {
      unsubscribeEmployees()
      unsubscribeActivities()
    }
  }, [])

  // Custom setter that syncs with cloud storage
  const setEmployees = async (newEmployees: any[]) => {
    setEmployeesState(newEmployees)
    await cloudStorage.set("attendanceEmployees", newEmployees)
  }

  // Add activity and sync with cloud storage
  const addActivity = async (activity: Activity) => {
    const newActivities = [...activities, activity]
    setActivities(newActivities)
    await cloudStorage.set("attendanceActivities", newActivities)
  }

  // Refresh data from cloud storage
  const refreshData = async () => {
    setIsLoading(true)
    try {
      const savedEmployees = await cloudStorage.get("attendanceEmployees")
      const savedActivities = await cloudStorage.get("attendanceActivities")

      if (savedEmployees) {
        setEmployeesState(savedEmployees)
      }

      if (savedActivities) {
        setActivities(savedActivities)
      }
    } catch (error) {
      console.error("Error refreshing data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AttendanceContext.Provider
      value={{
        employees,
        setEmployees,
        activities,
        addActivity,
        isLoading,
        refreshData,
      }}
    >
      {children}
    </AttendanceContext.Provider>
  )
}

export function useAttendanceData() {
  const context = useContext(AttendanceContext)
  if (context === undefined) {
    throw new Error("useAttendanceData must be used within an AttendanceProvider")
  }
  return context
}

